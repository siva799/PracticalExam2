package com.exam.Employee.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.Employee.exception.NoDataFoundException;
import com.exam.Employee.exception.NoEmployeeFoundException;
import com.exam.Employee.model.Employee;
import com.exam.Employee.repository.EmployeeRepository;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping("/employees") //retrival purpose
	public List<Employee> getAllEmployees() throws NoDataFoundException{
		return Optional.ofNullable(employeeRepository.findAll())//to get all the Employees
				.orElseThrow(()->new NoDataFoundException("No Data Found in the Employees"));  
	}
	
	@PostMapping("/employees") //to create new entity
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeRepository.save(employee); // to create employee details
	}
	
	@GetMapping("/employees/{id}") //get employee by its id
	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) throws NoEmployeeFoundException{
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(()->new NoEmployeeFoundException("No Employee exists with this id :" + id));
		return ResponseEntity.ok(employee);
	}
	@PutMapping("/employees/{id}") //to update or modity the details of employee
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id,@RequestBody Employee employees) throws NoEmployeeFoundException{
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(()->new NoEmployeeFoundException("No Employee exists with this id :" + id));
		
		employee.setFirstName(employees.getFirstName());
		employee.setLastName(employees.getLastName());
		employee.setEmailId(employees.getEmailId());
		
		Employee updaEmployee=employeeRepository.save(employee);
		return ResponseEntity.ok(updaEmployee);
		
	}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<Map<String,Boolean>> deleteEmployee(@PathVariable Long id) throws NoEmployeeFoundException{
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(()->new NoEmployeeFoundException("No Employee exists with this id :" + id));
		employeeRepository.delete(employee);
		Map<String, Boolean> res=new HashMap<>();
		res.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(res);
		
	}
	

}
