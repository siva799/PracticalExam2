package com.exam.Employee.exception;

import java.util.Arrays;

import lombok.NoArgsConstructor;
@NoArgsConstructor
public class NoDataFoundException extends Exception{
	public NoDataFoundException(String msg) {
		super(msg);
	}

	@Override
	public String toString() {
		return super.toString() + this.getMessage();
	}
	

}
