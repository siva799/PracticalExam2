package com.exam.Employee.exception;
import java.util.Arrays;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NoEmployeeFoundException extends Exception{
	public NoEmployeeFoundException(String message) {
		super(message);
	}

	@Override
	public String toString() {
		return super.toString() + this.getMessage();
	}
	

}
